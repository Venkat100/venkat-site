(function() {
  const root = document.documentElement;
  const toggle = document.getElementById('themeToggle');
  const key = 'vp-theme';
  const saved = localStorage.getItem(key);
  if (saved) root.setAttribute('data-theme', saved);

  toggle?.addEventListener('click', () => {
    const current = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', current);
    localStorage.setItem(key, current);
  });

  // Set year
  document.getElementById('year').textContent = new Date().getFullYear();

  // Subtle parallax on orbs
  const orbs = document.querySelectorAll('.orb');
  window.addEventListener('pointermove', (e) => {
    const { innerWidth:w, innerHeight:h } = window;
    const x = (e.clientX - w/2) / (w/2);
    const y = (e.clientY - h/2) / (h/2);
    orbs.forEach((o,i) => {
      const depth = (i+1) * 6;
      o.style.transform = `translate(${x*depth}px, ${y*depth}px)`;
    });
  }, { passive: true });
})();